import React from 'react'

function GreetingComponent(props) {
  return (
    <div>
      <h1>Hello Good Morning Shetty{props.name}</h1>
      <h1>Welcome Shetty{props.name}</h1>
    </div>
  )
}

export default GreetingComponent