import React, { Component } from 'react'

export default class GreetingFromClass extends Component {
  render() {
    return (
      <div>
        <h1>Hello Everyone!{this.name}</h1>
        <h1>age : 22{this.age}</h1>
      </div>
    )
  }
}
